# -*- coding: utf-8 -*-
r"""
=================================
Nifti-derived surfaces - GLM analysis
=================================

"""


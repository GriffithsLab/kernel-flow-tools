# -*- coding: utf-8 -*-
r"""
=================================
GLM based analysis
=================================

Blah blah

blah
blah
blah


*****************
Thing
*****************

Thingywot
==============

Blah blah


***********************
Anotherthing
***********************


Whatevs
=======================

Stuff
Stuff
Stuff

"""  # noqa:E501

import numpy as np
import pandas as pd
import mne

# sphinx_gallery_thumbnail_number = 1

# %%
# First we do a thing etc etc.

pd.DataFrame(np.random.normal(size=(16, 100))).plot(kind='hist')

# %%
#
# .. warning:: athing a not etc
#              blah blah
thisvar  = ['hbo', 'hbr', 'hbo', 'hbr',
            'hbo', 'hbr', 'hbo', 'hbr']

# %%
# More stuff etc blah
# blah blah
#montage = mne.channels.make_standard_montage('artinis-octamon')
#raw.set_montage(montage)

# View the position of optodes in 2D to confirm the positions are correct.
print('thing')#           ``something here`` to ``'eg'``.

#
# More stuff
# More stuff
#
# .. note:: Things

#f = ''
#res = run_pipeline(f,subselect_with='notnan')
